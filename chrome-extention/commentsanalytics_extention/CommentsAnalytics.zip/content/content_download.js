setTimeout(function() {
    var a = $("ytd-item-section-renderer > #contents > ytd-comment-thread-renderer");
    console.log(a.length);
    a.addClass("yt-comment");
    var f = function(c) {
            var b = {
                    Author: "",
                    Msg: ""
                },
                h = c.find("#author-text > span").text();
            b.Author = h.trim();
            b.Msg = c.find("#content-text").text().trim();
            return b
        },
        g = [];
    a.each(function() {
        var c = {},
            b = $(this);
        c = f(b.find(" > ytd-comment-renderer"));
        b = b.find("#replies");
        0 < b.length && b.find("ytd-comment-replies-renderer").find("ytd-comment-renderer").each(function() {
            c.Reply ||
                (c.Reply = []);
            c.Reply.push(f($(this)))
        });
        g.push(c)
    });
    a = document.createElement("a");
    document.body.appendChild(a);
    a.style = "display: none;visibility:hidden;opacity:0";
    var e = new Blob([JSON.stringify(g)], {
        type: "octet/stream"
    });
    e = window.URL.createObjectURL(e);
    a.href = e;
    var d = new Date;
    a.download = "export_" + d.getFullYear() + String(d.getMonth() + 1).padStart(2, "0") + String(d.getDate()).padStart(2, "0") + String(d.getHours()).padStart(2, "0") + String(d.getMinutes()).padStart(2, "0") + String(d.getSeconds()).padStart(2, "0") +
        ".json";
    a.click();
    window.URL.revokeObjectURL(e);
    document.body.removeChild(a)
}, 150);